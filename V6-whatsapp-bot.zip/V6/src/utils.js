export function getMessageText(message) {
  const content = message?.message;
  if (!content) return '';
  return (
    content.conversation ||
    content.extendedTextMessage?.text ||
    content.imageMessage?.caption ||
    content.videoMessage?.caption ||
    ''
  ).trim();
}

export function getMentionedJids(message) {
  const context = message?.message?.extendedTextMessage?.contextInfo;
  return Array.isArray(context?.mentionedJid) ? context.mentionedJid : [];
}

export function getSenderJid(message) {
  return message?.key?.participant || message?.participant || message?.key?.remoteJid || '';
}

export function cleanJid(jid) {
  return String(jid || '').trim();
}

export function jidNumber(jid) {
  return cleanJid(jid).split('@')[0].split(':')[0];
}

export function isValidUserJid(jid) {
  return typeof jid === 'string' && (jid.endsWith('@s.whatsapp.net') || jid.endsWith('@lid')) && jidNumber(jid).length >= 5;
}

export function formatName(user, jid) {
  const name = String(user?.name || '').trim();
  return name || `@${jidNumber(jid)}`;
}

export function formatNumber(n) {
  return Number(n).toLocaleString('en-US');
}
