export async function handleWelcome(sock, update) {
  if (update.action !== 'add' || !Array.isArray(update.participants) || update.participants.length === 0) return;

  const mentions = update.participants.filter(Boolean);
  const lines = mentions.map((jid) => `👋 مرحباً بك @${jid.split('@')[0].split(':')[0]}!`);

  await sock.sendMessage(update.id, {
    text: `🎉 أهلاً وسهلاً!\n\n${lines.join('\n')}\n\n🤖 مرحباً بك في المجموعة. اكتب !menu لمعرفة أوامر V6.`,
    mentions
  });
}
