import { getMentionedJids, getMessageText, getSenderJid, isValidUserJid, formatName, formatNumber, jidNumber } from './utils.js';

function isOwner(sender, owner) {
  const a = String(sender || '').split(':')[0];
  const b = String(owner || '').split(':')[0];
  return a === b || a === owner || sender === owner;
}

async function getGroupMetadata(sock, groupJid) {
  try {
    return await sock.groupMetadata(groupJid);
  } catch {
    return null;
  }
}

function findParticipant(participants, senderJid) {
  return participants?.find((p) => p?.id === senderJid || p?.jid === senderJid || p?.id?.split(':')[0] === senderJid?.split(':')[0]);
}

function participantIsAdmin(participant) {
  return participant?.admin === 'admin' || participant?.admin === 'superadmin';
}

async function canManage(sock, groupJid, senderJid, ownerJid) {
  if (isOwner(senderJid, ownerJid)) return true;
  const metadata = await getGroupMetadata(sock, groupJid);
  if (!metadata) return false;
  return participantIsAdmin(findParticipant(metadata.participants, senderJid));
}

function helpText() {
  return `🤖 *V6 — قائمة الأوامر*

🏆 *الكؤوس*
!setcoupe @الشخص 5 — إضافة 5 كؤوس
!coupe — كؤوسك
!coupe @الشخص — كؤوس شخص

⭐ *النقاط*
!setpoint @الشخص 500 — إضافة 500 نقطة
!point — نقاطك
!point @الشخص — نقاط شخص

🏅 *المتصدرون*
!top — Top 10 للكؤوس والنقاط

🛠️ *عام*
!menu
!help
!ping`;
}

function menuText() {
  return `🤖 *V6 BOT*

🏆 نظام الكؤوس
⭐ نظام النقاط
🏅 Top 10
👋 ترحيب تلقائي

اكتب !help لعرض جميع الأوامر.`;
}

function parsePositiveInteger(value) {
  if (!/^\d+$/.test(value)) return null;
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n <= 0 || n > 1_000_000_000) return null;
  return n;
}

function displayTarget(targetJid, db, fallbackName = '') {
  const user = db.getUser(targetJid, fallbackName);
  return { user, mention: `@${jidNumber(targetJid)}` };
}

function ranking(rows, emoji, field) {
  if (!rows.length) return `${emoji} لا توجد بيانات بعد.`;
  return rows.map((u, i) => `${i + 1}. @${jidNumber(u.jid)} — ${formatNumber(u[field])}`).join('\n');
}

export async function handleCommand(sock, message, { db, ownerJid }) {
  const text = getMessageText(message);
  if (!text.startsWith('!')) return;

  const remoteJid = message.key.remoteJid;
  const senderJid = getSenderJid(message);
  if (!remoteJid?.endsWith('@g.us') || !senderJid) return;

  const tokens = text.split(/\s+/).filter(Boolean);
  const command = tokens[0].toLowerCase();
  const args = tokens.slice(1);
  const mentioned = getMentionedJids(message).filter(isValidUserJid);

  const senderName = message.pushName || '';
  db.ensureUser(senderJid, senderName);

  if (command === '!ping') {
    await sock.sendMessage(remoteJid, { text: '🏓 Pong! V6 شغال ✅' });
    return;
  }

  if (command === '!menu' || command === '!help') {
    await sock.sendMessage(remoteJid, { text: command === '!menu' ? menuText() : helpText() });
    return;
  }

  if (command === '!coupe' || command === '!point') {
    const targetJid = mentioned[0] || senderJid;
    const target = displayTarget(targetJid, db, mentioned[0] ? '' : senderName);
    const value = command === '!coupe' ? target.user.cups : target.user.points;
    const emoji = command === '!coupe' ? '🏆' : '⭐';
    const label = command === '!coupe' ? 'الكؤوس' : 'النقاط';
    const textOut = `${emoji} ${label} لـ ${target.mention}: *${formatNumber(value)}*`;
    await sock.sendMessage(remoteJid, { text: textOut, mentions: [targetJid] });
    return;
  }

  if (command === '!top') {
    const cups = db.topCups();
    const points = db.topPoints();
    const out = `🏅 *V6 TOP 10*

🏆 *أفضل اللاعبين بالكؤوس*
${ranking(cups, '🏆', 'cups')}

⭐ *أفضل اللاعبين بالنقاط*
${ranking(points, '⭐', 'points')}`;
    const mentions = [...new Set([...cups, ...points].map((u) => u.jid))];
    await sock.sendMessage(remoteJid, { text: out, mentions });
    return;
  }

  if (command === '!setcoupe' || command === '!setpoint') {
    const allowed = await canManage(sock, remoteJid, senderJid, ownerJid);
    if (!allowed) {
      await sock.sendMessage(remoteJid, { text: '⛔ هذا الأمر متاح فقط لمالك البوت أو مشرفي المجموعة.' });
      return;
    }

    if (mentioned.length !== 1 || args.length < 2) {
      await sock.sendMessage(remoteJid, {
        text: command === '!setcoupe'
          ? '❌ الاستعمال الصحيح: !setcoupe @الشخص 5'
          : '❌ الاستعمال الصحيح: !setpoint @الشخص 500'
      });
      return;
    }

    const amount = parsePositiveInteger(args[args.length - 1]);
    if (amount === null) {
      await sock.sendMessage(remoteJid, { text: '❌ يجب أن يكون العدد رقماً صحيحاً موجباً.' });
      return;
    }

    const targetJid = mentioned[0];
    const current = db.getUser(targetJid, '');
    const updated = command === '!setcoupe'
      ? db.addCups(targetJid, amount, '')
      : db.addPoints(targetJid, amount, '');

    const emoji = command === '!setcoupe' ? '🏆' : '⭐';
    const label = command === '!setcoupe' ? 'كؤوس' : 'نقاط';
    const before = command === '!setcoupe' ? current.cups : current.points;
    const after = command === '!setcoupe' ? updated.cups : updated.points;

    await sock.sendMessage(remoteJid, {
      text: `${emoji} تمت إضافة *${formatNumber(amount)}* ${label} إلى @${jidNumber(targetJid)}.\nالرصيد: *${formatNumber(before)} → ${formatNumber(after)}*`,
      mentions: [targetJid]
    });
    return;
  }
}
