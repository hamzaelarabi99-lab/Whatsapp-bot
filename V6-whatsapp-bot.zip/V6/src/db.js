import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import config from '../config.js';

const databasePath = path.resolve(config.databasePath);
fs.mkdirSync(path.dirname(databasePath), { recursive: true });

const sqlite = new Database(databasePath);
sqlite.pragma('journal_mode = WAL');
sqlite.pragma('foreign_keys = ON');

sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    jid TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT '',
    cups INTEGER NOT NULL DEFAULT 0 CHECK(cups >= 0),
    points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0),
    updated_at INTEGER NOT NULL DEFAULT (unixepoch())
  );
`);

const statements = {
  upsertUser: sqlite.prepare(`
    INSERT INTO users (jid, name)
    VALUES (?, ?)
    ON CONFLICT(jid) DO UPDATE SET
      name = CASE WHEN excluded.name <> '' THEN excluded.name ELSE users.name END,
      updated_at = unixepoch()
  `),
  getUser: sqlite.prepare('SELECT jid, name, cups, points FROM users WHERE jid = ?'),
  addCups: sqlite.prepare('UPDATE users SET cups = cups + ?, updated_at = unixepoch() WHERE jid = ?'),
  addPoints: sqlite.prepare('UPDATE users SET points = points + ?, updated_at = unixepoch() WHERE jid = ?'),
  topCups: sqlite.prepare('SELECT jid, name, cups, points FROM users WHERE cups > 0 ORDER BY cups DESC, points DESC, jid ASC LIMIT 10'),
  topPoints: sqlite.prepare('SELECT jid, name, cups, points FROM users WHERE points > 0 ORDER BY points DESC, cups DESC, jid ASC LIMIT 10')
};

function ensureUser(jid, name = '') {
  if (!jid) throw new Error('Invalid JID');
  statements.upsertUser.run(jid, String(name || '').trim().slice(0, 100));
  return statements.getUser.get(jid);
}

export const db = {
  ensureUser,
  getUser(jid, name = '') {
    return ensureUser(jid, name);
  },
  addCups(jid, amount, name = '') {
    ensureUser(jid, name);
    statements.addCups.run(amount, jid);
    return statements.getUser.get(jid);
  },
  addPoints(jid, amount, name = '') {
    ensureUser(jid, name);
    statements.addPoints.run(amount, jid);
    return statements.getUser.get(jid);
  },
  topCups() {
    return statements.topCups.all();
  },
  topPoints() {
    return statements.topPoints.all();
  },
  close() {
    sqlite.close();
  }
};
